module HtmlUtil exposing (..)

import Html exposing (..)


empty : Html msg
empty =
    text ""
