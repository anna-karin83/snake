# Changelog for Bs v2.0.0

## Enhancements
- Movement client-response is now accessible in the world state under `world.moves[index].__meta__.response`
- Api responses are now Api.Response structs, providing access to the raw and parsed responses.
