[
  check_equivalent: true,
  line_length: 80,
  inputs: ["lib/**/*.{ex,exs}", "test/**/*.{ex,exs}"],
  locals_without_parens: []
]
