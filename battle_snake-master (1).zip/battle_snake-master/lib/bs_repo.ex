defmodule BsRepo do
  use Ecto.Repo, otp_app: :bs
end
