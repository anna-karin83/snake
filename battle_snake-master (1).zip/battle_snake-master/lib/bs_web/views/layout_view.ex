defmodule BsWeb.LayoutView do
  use BsWeb, :view
end
