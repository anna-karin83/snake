defmodule BsWeb.Test.SnakeTestView do
  use BsWeb, :view
end
