defmodule Bs.Event do
  defstruct [:name, rel: %{}, data: %{}]
end
