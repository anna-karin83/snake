defmodule BsWeb.LayoutViewTest do
  use BsWeb.ConnCase, async: true
end
