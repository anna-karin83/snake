Mox.defmock(Bs.HTTPMock, for: Bs.HTTP)
Mox.defmock(Bs.RepoMock, for: Ecto.Repo)
Mox.defmock(Bs.ApiMock, for: Bs.Api)
