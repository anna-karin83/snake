defmodule Bs.DataCase do
  use ExUnit.CaseTemplate

  using do
    quote do
    end
  end

  setup _tags do
    :ok
  end
end
